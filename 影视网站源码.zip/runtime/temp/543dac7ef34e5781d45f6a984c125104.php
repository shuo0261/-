<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"template/DYXS2/html/user/ajax_login.html";i:1621922890;}*/ ?>
<!--登录弹窗开始-->
<style>
	.user-bg {padding: 0 1rem;}
	.reg-w{width: 100%;}
	.reg-w form .reg-group {position: relative;border-bottom: 1px solid #f1f1f1;margin-top: 0.5rem;}
	.reg-w form .form-m-t{margin-top:0.25rem!important;}
	.reg-w form .btn-sub {width: 100%;border-radius: 4px;font-size: 0.375rem;padding: 0.3rem 0;margin: 0.75rem 0;}
	.btn-brand {display: inline-block;background: #ff2a14;color: #fff!important;border: none;cursor: pointer;}
	.reg-w form .reg-group label {display: inline-block;height: 1.125rem;line-height: 1.125rem;width: 20%;box-sizing: border-box;}
	.reg-w form .reg-group .reg-control {display: inline-block;width: 80%;height: 1.125rem; font-size: 0.35rem;border: none; background: none;}
	.reg-w form .reg-group .w150 {width: 50% !important;}
	.m-hi {width: 30%;height: 1.125rem;cursor: pointer;}
	.reg-ts {display: block;overflow: hidden;}
	.reg-od {margin-bottom: 0.25rem;overflow: hidden;}
	.reg-od span{color: #ff2a14;}
	.reg-ts .rega-fl {text-align: left;float: left;}
	.reg-ts .rega-fr {text-align: right;float: right;}
	.reg-dl {text-align: center;}
	.reg-dl h5 {font-size: 0.35rem;margin: 0 0 0.5rem; color: #999;padding-top: 0.25rem;width: 100%;}
	.reg-dl li {display: inline-flex;;overflow: hidden;margin: 0 0.375rem;font-size: 1rem;line-height: 1rem;}
	.reg-dl .reg-wx {color: #23CC21;}
	.reg-dl .reg-qq {color: #2AA2E5;}
	.pop_content{padding-top: 20px;}
	input::-webkit-input-placeholder {color: #ccc;}
</style>
<div id="member">
   <div class="user-bg">
	<div class="reg-w mac_login">
		<form class="mac_login_form" method="post" id="fm" action="">
			<div class="reg-group login_form_group form-m-t">
				<label class="bd-r" style="letter-spacing: normal;">账号</label><input type="text" name="user_name" class="mac_u_name reg-control" placeholder="输入手机号或登录账号">
			</div>
			<div class="reg-group login_form_group">
				<label>密码</label><input type="password" name="user_pwd" class="mac_u_pwd reg-control" placeholder="输入您的登录密码">
			</div>
			<?php if($GLOBALS['config']['user']['login_verify'] == 1): ?>
			<div class="reg-group login_form_group">
				<label>验证码</label><input type="text" class="mac_u_verify reg-control w150" name="verify" placeholder="输入验证码"><img class="mac_verify_img fr m-hi" src="<?php echo url('verify/index'); ?>" onClick="this.src=this.src+'?'"  alt="单击刷新" />
			</div>
			<?php endif; ?>
			<input type="button" class="login_form_submit btn-brand btn-sub" value="立即登录">
		</form>
		<div class="reg-ts">
			<div class="reg-od">
				<a class="rega-fl" href="<?php echo url('user/findpass'); ?>">忘记密码</a>
				<a class="rega-fr" href="<?php echo url('user/reg'); ?>"><span>注册账号</span></a>
			</div>
			<div class="reg-dl">
			<?php if($GLOBALS['config']['connect']['qq']['status'] == 1): ?>
			<h5>您还可以用以下方式登录</h5>
			<?php elseif($GLOBALS['config']['connect']['weixin']['status'] == 1): ?>
			<h5>您还可以用以下方式登录</h5>       
			<?php endif; ?>
				<ul>
					<?php if($GLOBALS['config']['connect']['weixin']['status'] == 1): ?>
					<li><a class="reg-wx" href="<?php echo url('user/oauth'); ?>?type=weixin"><i class="iconfont lishi">&#xe639;</i></a></li>
					<?php endif; if($GLOBALS['config']['connect']['qq']['status'] == 1): ?>
					<li><a class="reg-qq" href="<?php echo url('user/oauth'); ?>?type=qq"><i class="iconfont yonghu">&#xe637;</i></a></li>
					<?php endif; ?>
				</ul>
			</div>
        </div> 
	</div>
	</div>
</div>
<!--登录弹窗结束-->
