<?php if (!defined('THINK_PATH')) exit(); /*a:13:{s:35:"template/DYXS2/html/vod/detail.html";i:1620649034;s:67:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/include.html";i:1622314980;s:65:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/head1.html";i:1622218346;s:61:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/desc.html";i:1621923406;s:65:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/playlist.html";i:1620142572;s:65:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/downlist.html";i:1621909580;s:62:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/serie.html";i:1620648290;s:61:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/like.html";i:1620142612;s:66:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/vodbox.html";i:1620613830;s:60:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/vod/hot.html";i:1620172790;s:64:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/foot.html";i:1621911972;s:68:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/tcnotice.html";i:1620625578;s:67:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/website.html";i:1621912062;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
 <head> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title><?php echo $obj['vod_name']; ?>剧情介绍--<?php echo $maccms['site_name']; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta name="keywords" content="<?php echo $obj['type']['type_name']; ?><?php echo $obj['vod_name']; ?>_<?php echo $maccms['site_name']; ?>" />
  <meta name="description" content="<?php echo $obj['type']['type_name']; ?><?php echo $obj['vod_name']; ?>_<?php echo $maccms['site_name']; ?>" />
     <?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>

</head>
<body ontouchstart class="view page">
    
   <header id="header" class="wrapper">
	<div class="nav content">
		<div class="brand">
		<a href="<?php echo $maccms['path']; ?>" class="logo" title="<?php echo $maccms['site_url']; ?>&nbsp;-<?php echo $maccms['site_name']; ?>"><img src="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" alt="<?php echo $maccms['site_name']; ?>"></a>
		</div>
		<div class="nav-search">
			<form action="<?php echo mac_url('vod/search'); ?>">
				<div class="search-box">
					<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
					<div class="search-drop">
						<div class="drop-content-items ac_hot none">
							<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
							<div class="search-tag">
							<?php $_63a4454b91676=explode(',',$maccms['search_hot']); if(is_array($_63a4454b91676) || $_63a4454b91676 instanceof \think\Collection || $_63a4454b91676 instanceof \think\Paginator): if( count($_63a4454b91676)==0 ) : echo "" ;else: foreach($_63a4454b91676 as $key2=>$vo2): ?>
					       	<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						    <?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</div>
					</div>
					<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
					<button class="cancel-btn" type="button">取消</button>
				</div>
			</form>
		</div>
		<nav class="nav-menu">
			<ul class="nav-menu-items">
				<li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
					<a href="<?php echo $maccms['path']; ?>" class="white " title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
				</li>
				 <?php $__TAG__ = '{"num":"4","order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
				<li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
					<a class="nav-link white" href="<?php echo mac_url_type($vo); ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; endif; ?>
					<?php echo $vo['type_name']; ?> </a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy1name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy2name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
				<li class="nav-menu-item domain white "><i class="icon-domain"></i>网址<em>+</em></li>
				<?php endif; ?>
				<li class="space-line-bold white "></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-watch-history  white "></i>
                    </span>
					<div class="drop-content drop-history">
						<div class="drop-content-box">
							<ul class="drop-content-items" id="history">
								<li class="list-item list-item-title">
									<a href="" class="playlist historyclean">
										<i class="icon-clear"></i>
									</a>
									<strong>我的观影记录</strong>
								</li>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-all" style="color: #fff;"></i>
                    </span>
					<div class="drop-content sub-block">
						<div class="drop-content-box grid-box">
							<ul class="drop-content-items grid-items">
								<li class="grid-item">
									<a href="<?php echo $maccms['path']; ?>">
										<i class="icon-home"></i>
										<div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
									</a>
								</li>
							 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
								<li  class="grid-item">
									<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: ?>									    
										<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; case "5": ?>iconfont icon-zixun<?php break; ?>{/case}<?php default: ?>icon-zixun<?php endswitch; ?>"></i><?php endif; ?>
										<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('label/web'); ?>"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['topic'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('topic/index'); ?>"><i class="iconfont icon-zhuanxiangxinxi"></i>
								<div class="grid-item-name" title="专题">专题</div>
								</a>
								</li>
								<?php endif; ?>
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
								<?php if($dyxsst['dycms']['s2']['app'] == 1): ?>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<?php if($dyxsst['dycms']['s2']['user'] == 1): ?>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
				<?php if($user['group']['group_id'] == 1): ?>
				<a href="<?php echo mac_url('user/login'); ?>" class=" white " title="用户登录"><i class="iconfont icon-yonghu"></i></a>
				<?php else: ?>
				<a href="<?php echo mac_url('user/index'); ?>" class=" white " title="个人中心"><i class="iconfont icon-yonghu"></i></a>				
				</li>
				<?php endif; endif; ?>
			</ul>
		</nav>
	</div>
</header>   <!-- 头部 -->
   <main id="main" class="wrapper">
   	<div class="content">   
   	
                <div class="box view-heading">
			<div class="mobile-play">
				<div class="module-item-cover">
					<div class="module-item-pic"><img class="lazyload" data-src="<?php echo mac_url_img($obj['vod_pic']); ?>" src="<?php echo $maccms['path_tpl']; ?>static/picture/loading.png"></div>
				</div>
			</div>
			<div class="video-cover">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_play($obj); ?>" title="立刻播放<?php echo $obj['vod_name']; ?>"><i class="icon-play"></i></a><img class="lazyload" alt="<?php echo $obj['vod_name']; ?>" data-src="<?php echo mac_url_img($obj['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>">
						<div class="loading"></div>
					</div>
				</div>
			</div>
			<div class="video-info">
				<div class="video-info-header">
					<h1 class="page-title"><?php echo $obj['vod_name']; ?></h1>
					
					<h2 class="video-subtitle" title="又名：<?php echo $obj['vod_en']; ?>"><?php echo $obj['vod_en']; ?></h2>
					
					<div class="video-info-aux">
						<a href="<?php if($obj['type_1']!=''): ?><?php echo mac_url_type($obj['type_1']); else: ?><?php echo mac_url_type($obj['type']); endif; ?>" title="<?php if($obj['type_1']!=''): ?><?php echo $obj['type_1']['type_name']; else: ?><?php echo $obj['type']['type_name']; endif; ?>" class="tag-link">
						    <span class="video-tag-icon">
						  <?php if($obj['type_id_1'] == 1||$obj['type_id'] == 1): ?>
                            <i class="icon-cate-dy"></i>
                             <?php elseif($obj['type_id_1'] == 2||$obj['type_id'] == 2): ?>
                            <i class="icon-cate-ds"></i>
                            <?php elseif($obj['type_id_1'] == 3||$obj['type_id'] == 3): ?>
                            <i class="icon-cate-zy"></i>
                            <?php elseif($obj['type_id_1'] == 4||$obj['type_id'] == 4): ?>
                             <i class="icon-cate-dm"></i>
                             <?php else: endif; if($obj['type_1']!=''): ?><?php echo $obj['type_1']['type_name']; else: ?><?php echo $obj['type']['type_name']; endif; ?>
						     </span>
						      </a>
				    	<div class="tag-link">
						<span class="slash">/</span>    
					    <?php $_63a4454b913c1=explode(',',$obj['vod_class']); if(is_array($_63a4454b913c1) || $_63a4454b913c1 instanceof \think\Collection || $_63a4454b913c1 instanceof \think\Paginator): if( count($_63a4454b913c1)==0 ) : echo "" ;else: foreach($_63a4454b913c1 as $key2=>$vo2): ?>	    
						<a href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'class'=>$vo2],'show'); ?>"><?php echo $vo2; ?></a><span class="slash">/</span>
						<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>
						
						<a class="tag-link" href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'year'=>$obj['vod_year']],'show'); ?>"><?php echo mac_default($obj['vod_year'],'未知'); ?>	</a>
						
                        <a class="tag-link" href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'area'=>$obj['vod_area']],'show'); ?>"><?php echo mac_default($obj['vod_area'],'未知'); ?>	</a>
                        
					</div>
					
					<a href="<?php echo mac_url_vod_play($obj); ?>" class="btn-important btn-large shadow-drop video-info-play" title="立刻播放<?php echo $obj['vod_name']; ?>"><i class="icon-play"></i><strong>立即播放</strong>
					</a>
					
				</div>
				
				<div class="video-info-main">

					<div class="video-info-items"><span class="video-info-itemtitle">导演：</span>
						<div class="video-info-item video-info-actor"><span class="slash">/</span>
					    <?php echo mac_url_create(mac_default($obj['vod_director'],'未知'),'director','vod','search','<span class="slash">/</span>'); ?>
						</div>
					</div>
					<div class="video-info-items"><span class="video-info-itemtitle">主演：</span>
						<div class="video-info-item video-info-actor"><span class="slash">/</span>
						<?php echo mac_url_create(mac_default($obj['vod_actor'],'未知'),'actor','vod','search','<span class="slash">/</span>'); ?>
						</div>
					</div>
		            <div class="video-info-items" itemscope="" itemprop="director" itemtype="http://schema.org/Person">
		                <span class="video-info-itemtitle">年代：</span>
		                <div class="video-info-item video-info-actor">
		                    <?php echo mac_url_create($obj['vod_year'],'year'); ?>
		                </div>
		            </div>		            
					<div class="video-info-items"><span class="video-info-itemtitle">  <?php if($obj['type_id_1'] == 4||$obj['type_id'] == 4): ?>连载：<?php elseif($obj['type_id_1'] == 2||$obj['type_id'] == 2): ?>集数：<?php else: ?>备注：<?php endif; ?></span>
						<div class="video-info-item"><?php if($obj['vod_remarks'] != ''): ?><?php echo $obj['vod_remarks']; elseif($obj['vod_serial'] > 0): ?>第<?php echo $obj['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
					</div>
					<div class="video-info-items"><span class="video-info-itemtitle">剧情：</span>
						<div class="video-info-item video-info-content">
							<p class="zkjj_a" ><?php echo mac_substring($obj['vod_blurb'],150); ?><span class="zk_jj red">[展开全部]</span></p><p class="sqjj_a" style="display: none;">　<?php echo mac_filter_html($obj['vod_content']); ?><span class="sq_jj red">[收起部分]</span></p>
							</div>
					</div>
				</div>
				<div class="video-info-footer display">
			            	<?php if(!(empty($obj[vod_play_from]) || (($obj[vod_play_from] instanceof \think\Collection || $obj[vod_play_from] instanceof \think\Paginator ) && $obj[vod_play_from]->isEmpty()))): if($GLOBALS['config']['user']['status'] == 1): ?>
					        <div class="fav-btn">
						    <span title="加入收藏">
								<a href="javascript:void(0);" style="cursor:hand" class="mac_ulog" data-type="2" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>"><i class="iconfont icon-jiarushoucang"></i></a>
							</span>
							</div>
							<?php endif; ?>				    
					<div class="video-info-share">
						<button class="share-btn" data-clipboard-text="<?php echo $maccms['site_url']; ?><?php echo mac_url_vod_detail($obj); ?> 我正在<?php echo $maccms['site_name']; ?>观看《<?php echo $obj['vod_name']; ?>》，推荐给你一起看！">好影片，与好朋友一起分享<i class="icon-happy"></i></button>
					</div>		
					<a href="<?php echo mac_url_vod_play($obj); ?>" class="btn-important btn-large shadow-drop" title="立刻播放<?php echo $obj['vod_name']; ?>"><i class="icon-play"></i><strong>立即播放</strong></a>
					<?php endif; if(!(empty($obj[vod_down_from]) || (($obj[vod_down_from] instanceof \think\Collection || $obj[vod_down_from] instanceof \think\Paginator ) && $obj[vod_down_from]->isEmpty()))): ?>
					<span class="btn-aux btn-aux-o btn-large gotodownloadlist"><i class="icon-download" onclick="click_scroll();"></i><strong>下载</strong></span>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<script>
		 $(".sq_jj").click(function(){
          $(".sqjj_a").toggle();
          $(".zkjj_a").toggle();
        });
      $(".zk_jj").click(function(){
          $(".sqjj_a").toggle();
          $(".zkjj_a").toggle();
      });
      $('.gotodownloadlist').click(function(){$('html,body').animate({scrollTop:$('#download-list').offset().top}, 800);});   
		</script>
		       <!-- 简介 -->
    
            <div class="module">
      <div class="module-heading">
          <h2 class="module-title" title="<?php echo $obj['vod_name']; ?>在线观看列表">在线观看</h2>
            倒序
          <div class="module-tab module-player-tab ">
            <input type="hidden" name="tab" id="tab" class="module-tab-input">
            <label class="module-tab-name"><span class="module-tab-value">切换节点</span><i class="icon-arrow-bottom-o"></i></label>
              <div class="module-tab-items">
              <div class="module-tab-title">播放节点列表<span class="close-drop"><i class="icon-close-o"></i></span></div>
              <div class="module-tab-content">
               <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>	  
               <div class="module-tab-item tab-item" data-dropdown-value="<?php echo $vo['player_info']['show']; ?>"><span><?php echo $vo['player_info']['show']; ?></span><small><?php echo $vo['url_count']; ?></small></div>
               <?php endforeach; endif; else: echo "" ;endif; ?>	
                </div>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
        </div>
        <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>	
        <div class="module-list module-player-list tab-list sort-list <?php switch($obj['type_id_1']): case "3": ?>module-vod-list<?php break; endswitch; ?>   " id="glist-<?php echo $key; ?>">
          <div class="module-tab module-sorttab">
            <input type="hidden" name="tab-sort" id="tab-sort" class="module-tab-input">
            <label class="module-tab-name"><i class="icon-all"></i></label>
            <div class="module-tab-items">
              <div class="module-tab-title">选集<span class="close-drop"><i class="icon-close-o"></i></span><a class="desc sort-button" href="javascript:void(0);" to="#sort-item-<?php echo $key; ?>"><i class="icon-sort"></i>排序</a></div>
              <div class="module-tab-content">
                <div class="module-blocklist">
                  <div class="sort-item" id="sort-item-<?php echo $key; ?>">
                   <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?> 
                   <a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" title="播放<?php echo $obj['vod_name']; ?><?php echo $vo2['name']; ?>"><span><?php echo $vo2['name']; ?></span></a>
                    <?php endforeach; endif; else: echo "" ;endif; ?>                  
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
          <div class="module-blocklist scroll-box scroll-box-y">
            <div class="scroll-content">
             <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?> 
            <a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" title="播放<?php echo $obj['vod_name']; ?><?php echo $vo2['name']; ?>"><span><?php echo $vo2['name']; ?></span></a>
             <?php endforeach; endif; else: echo "" ;endif; ?>                   
           </div>
          </div>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <script type="text/javascript">$(".tab-item:first,.module-list:first").addClass("selected");</script>   <!-- 播放列表 -->
    
    <?php if(!(empty($obj[vod_down_from]) || (($obj[vod_down_from] instanceof \think\Collection || $obj[vod_down_from] instanceof \think\Paginator ) && $obj[vod_down_from]->isEmpty()))): ?>
<div class="module" id="download-list" name="download-list">
	<div class="module-heading">
		<h2 class="module-title" title="<?php echo $obj['vod_name']; ?>的影片下载列表">影片下载</h2>
		<div class="module-tab module-player-tab"><input type="hidden" name="downtab" id="downtab" class="module-tab-input"><label class="module-tab-name"><span class="module-tab-value"><?php echo $obj['vod_down_list'][$param['sid']]['player_info']['show']; ?></span><i class="icon-arrow-bottom-o"></i></label>
			<div class="module-tab-items">
				<div class="module-tab-title">影片资源版本<span class="close-drop"><i class="icon-close-o"></i></span></div>
				<div class="module-tab-content">
				     <?php if(is_array($obj['vod_down_list']) || $obj['vod_down_list'] instanceof \think\Collection || $obj['vod_down_list'] instanceof \think\Paginator): if( count($obj['vod_down_list'])==0 ) : echo "" ;else: foreach($obj['vod_down_list'] as $key=>$vo): ?>
					<div class="module-tab-item downtab-item <?php if($key == 1): ?> selected<?php endif; ?>"><span data-dropdown-value="<?php echo $vo['player_info']['show']; ?>"><?php echo $vo['player_info']['show']; ?></span><small><?php echo $vo['url_count']; ?></small></div>
					 <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>
		<div class="shortcuts-mobile-overlay"></div>
	</div>
	<div class="module-list module-player-list sort-list module-downlist selected">
		<div class="scroll-box-y">
		    <?php if(is_array($obj['vod_down_list']) || $obj['vod_down_list'] instanceof \think\Collection || $obj['vod_down_list'] instanceof \think\Paginator): if( count($obj['vod_down_list'])==0 ) : echo "" ;else: foreach($obj['vod_down_list'] as $key=>$vo): ?>
			<div class="module-row-one">
			       <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?>
				<div class="module-row-info">
					<a class="module-row-text copy" href="javascript:;" data-clipboard-text="<?php echo $vo2['url']; ?>" title="复制《<?php echo $obj['vod_name']; ?>》<?php echo $vo2['name']; ?>下载地址"><i class="icon-video-file"></i>
						<div class="module-row-title">
							<h4><?php echo $obj['vod_name']; ?> - <?php echo $vo2['name']; ?></h4>
							<p><?php echo $vo2['url']; ?></p>
						</div>
					</a>
					<div class="module-row-shortcuts">
						<a class="btn-pc btn-down" href="<?php echo $vo2['url']; ?>" title="下载《<?php echo $obj['vod_name']; ?>》<?php echo $vo2['name']; ?>"><i class="icon-download"></i><span>下载</span></a>
						<a class="btn-copyurl copy" href="javascript:;" data-clipboard-text="<?php echo $vo2['url']; ?>" title="复制《<?php echo $obj['vod_name']; ?>》<?php echo $vo2['name']; ?>下载地址"><i class="icon-url"></i><span class="btn-pc">复制链接</span></a>
					</div>
				</div>
				    <?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
			 <?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
</div>
	
<?php endif; ?>   <!-- 下载列表 -->
    
	<!--AD2-->
		<?php if($dyxsst['dycms']['s3']['ad2'] == 1): ?>
	<div class="index-recommend recommend-list"><a href="<?php echo $dyxsst['dycms']['s3']['ad2_url']; ?>" target="_blank"><div class="pc"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad2_pc']); ?>"></div><div class="phone"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad2_wap']); ?>"></div></a></div>
	<?php endif; ?>
	<!---->    
    
    <?php if(!(empty($obj[vod_rel_vod]) || (($obj[vod_rel_vod] instanceof \think\Collection || $obj[vod_rel_vod] instanceof \think\Paginator ) && $obj[vod_rel_vod]->isEmpty()))): ?>
<div class="module">
	<div class="module-heading">
		<h2 class="module-title" title="<?php echo $obj['vod_name']; ?>同系列影片">系列影片</h2></div>
	<div class="module-list module-lines-list">
		<div class="module-items scroll-box">
			<div class="scroll-content">
			    <?php $__TAG__ = '{"num":"6","rel":"'.$obj['vod_rel_vod'].'","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<div class="module-item module-item-go">
					<div class="module-item-cover">
						<div class="module-item-pic">
							<a href="<?php echo mac_url_vod_play($vo); ?>" title="立刻播放<?php echo $vo['vod_name']; ?>"><i class="icon-play"></i></a><img class=" ls-is-cached  lazy lazyloaded" data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>" alt="<?php echo $vo['vod_name']; ?>">
							<div class="loading"></div>
						</div>
						<div class="module-item-caption"></div>
					</div>
					<div class="module-item-titlebox">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
					</div>
					<div class="module-item-text"><span><?php echo $vo['vod_year']; ?>年</span></div>
				</div>
				    <?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>   <!-- 系列影片 -->
    
        	<div class="module">
			<div class="module-heading">
			<h2 class="module-title" title="与<?php echo $obj['vod_name']; ?>相关的影片列表">相关影片</h2>
			</div>
			<div class="module-list module-lines-list">
				<div class="module-items">
				<?php $__TAG__ = '{"num":"16","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>	
				                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		        <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>
		       <!-- 相关影片 -->
    
    	   <div class="module">
			<div class="module-heading">
				<h2 class="module-title">正在热播</h2>
				<a class="more" href="<?php echo mac_url_type($vo,[],'show'); ?>" title="更多">更多<i class="icon-arrow-right-o"></i></a>
			</div>
			<div class="module-list module-lines-list">
				<div class="module-items">
				<?php $__TAG__ = '{"num":"6","type":"all","order":"asc","by":"time","level":"8","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>	
				                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		        <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>       <!-- 正在热播 -->
   
   	</div>
   </main>
   
   <footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
 <!-- 底部-->
   
   <div class="shortcuts-box"><div id="shortcuts-info"></div></div>
   <span class="mac_ulog_set none" alt="设置播放页浏览记录" data-type="4" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-sid="<?php echo $param['sid']; ?>" data-nid="<?php echo $param['nid']; ?>"></span>
<span class="mac_hits none" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-type="hits"></span>
 </body>
</html>