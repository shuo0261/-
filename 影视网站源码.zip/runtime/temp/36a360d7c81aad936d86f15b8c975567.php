<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"/www/wwwroot/ruanjianku.pro/application/admin/view/extend/urlsend/baidu.html";i:1629786408;}*/ ?>
<div class="layui-tab-item ">

    <div class="layui-form-item">
        <label class="layui-form-label">token：</label>
        <div class="layui-input-inline  ">
            <input type="text" class="layui-input" value="<?php echo $config['baidu']['token']; ?>" placeholder="" name="urlsend[baidu][token]">
        </div>
    </div>

</div>