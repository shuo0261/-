<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:35:"template/DYXS2/html/user/login.html";i:1621723682;s:67:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/include.html";i:1622314980;s:65:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/user/include.html";i:1621991990;s:65:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/head1.html";i:1622218346;s:64:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/foot.html";i:1621911972;s:68:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/tcnotice.html";i:1620625578;s:67:"/www/wwwroot/ruanjianku.pro/template/DYXS2/html/public/website.html";i:1621912062;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<title>用户登录 - <?php echo $maccms['site_name']; ?></title>
	<meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>"/>
	<meta name="description" content="<?php echo $maccms['site_description']; ?>"/>
	<?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>

	 <link href="<?php echo $maccms['path_tpl']; ?>static/css/dyxs.css" rel="stylesheet" type="text/css">
 <script src="<?php echo $maccms['path']; ?>static/js/jquery.imageupload.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/layui@2.6.7/dist/layui.js"></script>
<style>
    .checkboxinput{-webkit-appearance: checkbox;}
    .nonemore{background: none;}
    [class^=icon-], [class*=" icon-"]{line-height: inherit!important;}
    button.btn-face {
    border-radius: 50%;
    width: 60px;
    height: 60px;
    font-size: 12px;
    background: darkgray;
}
</style>
</head>
<body class="article page">
<header id="header" class="wrapper">
	<div class="nav content">
		<div class="brand">
		<a href="<?php echo $maccms['path']; ?>" class="logo" title="<?php echo $maccms['site_url']; ?>&nbsp;-<?php echo $maccms['site_name']; ?>"><img src="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" alt="<?php echo $maccms['site_name']; ?>"></a>
		</div>
		<div class="nav-search">
			<form action="<?php echo mac_url('vod/search'); ?>">
				<div class="search-box">
					<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
					<div class="search-drop">
						<div class="drop-content-items ac_hot none">
							<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
							<div class="search-tag">
							<?php $_63a44d8dd6091=explode(',',$maccms['search_hot']); if(is_array($_63a44d8dd6091) || $_63a44d8dd6091 instanceof \think\Collection || $_63a44d8dd6091 instanceof \think\Paginator): if( count($_63a44d8dd6091)==0 ) : echo "" ;else: foreach($_63a44d8dd6091 as $key2=>$vo2): ?>
					       	<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						    <?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</div>
					</div>
					<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
					<button class="cancel-btn" type="button">取消</button>
				</div>
			</form>
		</div>
		<nav class="nav-menu">
			<ul class="nav-menu-items">
				<li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
					<a href="<?php echo $maccms['path']; ?>" class="white " title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
				</li>
				 <?php $__TAG__ = '{"num":"4","order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
				<li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
					<a class="nav-link white" href="<?php echo mac_url_type($vo); ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; endif; ?>
					<?php echo $vo['type_name']; ?> </a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy1name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy2name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
				<li class="nav-menu-item domain white "><i class="icon-domain"></i>网址<em>+</em></li>
				<?php endif; ?>
				<li class="space-line-bold white "></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-watch-history  white "></i>
                    </span>
					<div class="drop-content drop-history">
						<div class="drop-content-box">
							<ul class="drop-content-items" id="history">
								<li class="list-item list-item-title">
									<a href="" class="playlist historyclean">
										<i class="icon-clear"></i>
									</a>
									<strong>我的观影记录</strong>
								</li>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-all" style="color: #fff;"></i>
                    </span>
					<div class="drop-content sub-block">
						<div class="drop-content-box grid-box">
							<ul class="drop-content-items grid-items">
								<li class="grid-item">
									<a href="<?php echo $maccms['path']; ?>">
										<i class="icon-home"></i>
										<div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
									</a>
								</li>
							 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
								<li  class="grid-item">
									<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: ?>									    
										<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; case "5": ?>iconfont icon-zixun<?php break; ?>{/case}<?php default: ?>icon-zixun<?php endswitch; ?>"></i><?php endif; ?>
										<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('label/web'); ?>"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['topic'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('topic/index'); ?>"><i class="iconfont icon-zhuanxiangxinxi"></i>
								<div class="grid-item-name" title="专题">专题</div>
								</a>
								</li>
								<?php endif; ?>
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
								<?php if($dyxsst['dycms']['s2']['app'] == 1): ?>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<?php if($dyxsst['dycms']['s2']['user'] == 1): ?>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
				<?php if($user['group']['group_id'] == 1): ?>
				<a href="<?php echo mac_url('user/login'); ?>" class=" white " title="用户登录"><i class="iconfont icon-yonghu"></i></a>
				<?php else: ?>
				<a href="<?php echo mac_url('user/index'); ?>" class=" white " title="个人中心"><i class="iconfont icon-yonghu"></i></a>				
				</li>
				<?php endif; endif; ?>
			</ul>
		</nav>
	</div>
</header>
<main id="main" class="wrapper">
			<div class="content">
				<div>
					<h1 class="page-title">登录账号</h1>				
					<div class="box">    <!-- 头部 -->
<div class="dyxs_login__form clearfix">
	<div class="dyxs-pannel dyxs-pannel-bg clearfix">
		<div class="dyxs-pannel-box clearfix">		
			<div class="dyxs-pannel_bd">

				<ul class="input-list">				
					<form method="post" id="fm" action="">					
						<li>
							<input type="text" id="user_name" name="user_name" class="form-control" placeholder="请输入您的登录账号">
						</li>
						<li>
							<input type="password" id="user_pwd" name="user_pwd" class="form-control" placeholder="请输入您的登录密码">
						</li>
						<?php if($GLOBALS['config']['user']['login_verify'] == 1): ?>
						<li>
							<img class="pull-right" id="verify_img" src="<?php echo url('verify/index'); ?>" onClick="this.src=this.src+'?'"  alt="单击刷新" />
							<input type="text" class="form-control" id="verify" name="verify" placeholder="请输入验证码" style="width: 120px;">					
						</li>
						<?php endif; ?>					
						<li>
							<button type="button" id="btn_submit" class="btn btn-lg btn-block btn-primary">立即登录</button>
						</li>
						<li class="text-center">
							<a href="<?php echo $maccms['path']; ?>">返回首页</a><span class="split-line"></span><a href="<?php echo url('user/reg'); ?>">注册账号</a><span class="split-line"></span><a href="<?php echo url('user/findpass'); ?>">找回密码</a>
						</li>
					</form>
				</ul>			
				<div class="another top-line">
					<p class="text-muted">第三方快捷登录</p>
					<?php if($GLOBALS['config']['connect']['qq']['status'] == 1): ?>
					<a href="<?php echo url('user/oauth'); ?>?type=qq"><img src="<?php echo $maccms['path_tpl']; ?>static/image/qq.png" width="24" alt="QQ登录"/></a>
					<?php endif; if($GLOBALS['config']['connect']['weixin']['status'] == 1): ?>
					<a href="<?php echo url('user/oauth'); ?>?type=weixin"><img src="<?php echo $maccms['path_tpl']; ?>static/image/weixin.png" width="24" alt="微信登录"/></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
						<div class="article-bg"></div>
						<div class="article-bg01"></div>
					</div>
				</div>
			</div>
		</main>
<footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
  
<!-- // sign-box#regbox end -->
<script type="text/javascript">

	$(function(){
		$("body").bind('keyup',function(event) {
			if(event.keyCode==13){ $('#btn_submit').click(); }
		});
		$('#btn_submit').click(function() {
			if ($('#user_name').val()  == '') { layer.msg('请输入用户！'); $("#user_name").focus(); return false; }
			if ($('#user_pwd').val()  == '') { layer.msg('请输入密码！'); $("#user_pwd").focus(); return false; }
			if ($('#verify').length> 0 && $('#verify').val()  == '') { layer.msg('请输入验证码！'); $("#verify").focus(); return false; }

			$.ajax({
				url: "<?php echo url('user/login'); ?>",
				type: "post",
				dataType: "json",
				data: $('#fm').serialize(),
				beforeSend: function () {
					$("#btn_submit").css("background","#fd6a6a").val("loading...");
				},
				success: function (r) {
					if(r.code==1){
						location.href="<?php echo url('user/index'); ?>";
					}
					else{
						layer.msg(r.msg);
						$('#verify_img').click();
					}
				},
				complete: function () {
					$("#btn_submit").css("background","#fa4646").val("立即登录");
				}
			});

		});
	});

</script>

</body>
</html>