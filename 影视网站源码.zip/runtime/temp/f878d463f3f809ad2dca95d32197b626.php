<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"/www/wwwroot/ruanjianku.pro/application/admin/view/extend/urlsend/baidufast.html";i:1629786408;}*/ ?>
<div class="layui-tab-item ">

    <div class="layui-form-item">
        <label class="layui-form-label">token：</label>
        <div class="layui-input-inline  ">
            <input type="text" class="layui-input" value="<?php echo $config['baidufast']['token']; ?>" placeholder="" name="urlsend[baidufast][token]">
        </div>
    </div>

</div>